import math

def set_lr(optimizer, lr):
    for param_group in optimizer.param_groups:
        param_group['lr'] = lr

def get_lr(optimizer):
    return optimizer.param_groups[0]['lr']

def set_cos_lr(epoch, step_epoch, total_epoch, optimizer, base_lr):
    if epoch <=step_epoch:
        epochs = step_epoch
        min_lr = 1e-4
        start_epoch = 100
        end_epoch = 0
    else: # 201~250 epoch  300
        epoch = epoch - step_epoch  #50
        epochs = total_epoch - step_epoch #50
        min_lr = 5e-6
        base_lr = base_lr * 0.1
        # 0-1 epoch
        start_epoch = 0
        end_epoch = 1
    # use cos lr
    if epoch > start_epoch and epoch <= epochs - end_epoch:  #101~200 epoch / 201~249 epoch
        # use cos lr
        tmp_lr = min_lr + 0.5*(base_lr-min_lr) * \
            (1+math.cos(math.pi*(epoch-start_epoch)*1. / (epochs-start_epoch-end_epoch)))
        set_lr(optimizer, tmp_lr)
    elif epoch > epochs - end_epoch: #250 epoch    100-1=99
        tmp_lr = min_lr  #5e-6
        set_lr(optimizer, tmp_lr)
    else:
        tmp_lr = base_lr
    # print(get_lr(optimizer))


# 余弦退火学习率
# min_lr: 1e-4, 5e-6
# base_lr: 1e-3, 1e-4
# epoch
# start_epoch: 1
# epochs: 250
# end_epoch: 0
def cos_lr(optimizer, min_lr, base_lr, epoch, start_epoch=1, epochs=300, end_epoch=0):
    lr = min_lr + 0.5 * (base_lr - min_lr) * \
             (1 + math.cos(math.pi * (epoch - start_epoch) * 1. / (epochs - start_epoch - end_epoch)))
    set_lr(optimizer, lr)
    return lr


# 学习率预热
def set_warm_up(epoch, epoch_size, iter_i, optimizer, base_lr):
    # WarmUp strategy for learning rate
    epoch_limit = 1
    if epoch < epoch_limit:
        # 对学习率进行调整
        tmp_lr = base_lr * pow((iter_i+epoch*epoch_size)
                                * 1. / (epoch_limit*epoch_size), 4)
        set_lr(optimizer, tmp_lr)
    elif epoch == epoch_limit and iter_i == 0:
        tmp_lr = base_lr
        set_lr(optimizer, tmp_lr)


