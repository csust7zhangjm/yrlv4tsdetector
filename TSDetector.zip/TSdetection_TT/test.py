#!/usr/bin/python3.7
import argparse

from utils.datasets import *
from utils.evaluation import *
import torch.nn as nn

torch.manual_seed(0)  # 设置随机数种子
torch.cuda.manual_seed(0)  # 为GPU设置随机种子（只用一块）
torch.cuda.manual_seed_all(0)  # 为所有GPU设置随机种子
os.environ['PYTHONHASHSEED'] = str(0)

from utils.tool import *
from models.detector_test import Detector

import time


if __name__ == '__main__':
    # 指定训练配置文件
    parser = argparse.ArgumentParser()
    parser.add_argument('--yaml', type=str, default="configs/sign.yaml", help='.yaml config')
    parser.add_argument('--weight', type=str, default="checkpoint/weight_AP05:0.774019_290-epoch.pth", help='.weight config')
    parser.add_argument('--img', type=str, default='img/', help='The path of test image')
    parser.add_argument('--img_out', type=str, default='map_out/img_out/', help='The path of test image')
    parser.add_argument('--filters_out', type=str, default='map_out/filters_out/', help='The path of filters image')
    parser.add_argument('--thresh', type=float, default=0.5, help='The path of test image')
    parser.add_argument('--onnx', action="store_true", default=False, help='Export onnx file')
    parser.add_argument('--torchscript', action="store_true", default=False, help='Export torchscript file')
    parser.add_argument('--cpu', action="store_true", default=False, help='Run on cpu')

    opt = parser.parse_args()
    assert os.path.exists(opt.yaml), "请指定正确的配置文件路径"
    assert os.path.exists(opt.weight), "请指定正确的模型路径"
    assert os.path.exists(opt.img), "请指定正确的测试图像路径"

    # 选择推理后端
    if opt.cpu:
        print("run on cpu...")
        device = torch.device("cpu")
    else:
        if torch.cuda.is_available():
            print("run on gpu...")
            device = torch.device("cuda")
        else:
            print("run on cpu...")
            device = torch.device("cpu")

    # 解析yaml配置文件
    cfg = LoadYaml(opt.yaml)
    print(cfg)

    # 模型加载
    print("load weight from:%s" % opt.weight)
    model = Detector(cfg.category_num)
    #model = nn.DataParallel(model)  #采用分布式训练
    model = model.to(device)
    # 导入权重
    model.load_state_dict(torch.load(opt.weight, map_location=device)["model"]) ##
    # sets the models in eval node
    model.eval()

    img_root = opt.img
    dir_save_path = opt.img_out
    filters_save_path = opt.filters_out
    imgs_list = [os.path.join(img_root, im) for im in os.listdir(img_root)]
    pts, gts = [], []
    totalTime = 0.0
    for img_path in imgs_list:

        # 数据预处理
        ori_img = cv2.imread(img_path)
        res_img = cv2.resize(ori_img, (cfg.input_width, cfg.input_height), interpolation=cv2.INTER_LINEAR)
        img = res_img.reshape(1, cfg.input_height, cfg.input_width, 3)
        img = torch.from_numpy(img.transpose(0, 3, 1, 2))
        img = img.to(device).float() / 255.0

        '''
        # 导出onnx模型
        if opt.onnx:
            torch.onnx.export(model,  # model being run
                              img,  # model input (or a tuple for multiple inputs)
                              "./FastestDet.onnx",  # where to save the model (can be a file or file-like object)
                              export_params=True,  # store the trained parameter weights inside the model file
                              opset_version=11,  # the ONNX version to export the model to
                              do_constant_folding=True)  # whether to execute constant folding for optimization
            # onnx-sim
            onnx_model = onnx.load("./FastestDet.onnx")  # load onnx model
            model_simp, check = simplify(onnx_model)
            assert check, "Simplified ONNX model could not be validated"
            print("onnx sim sucess...")
            onnx.save(model_simp, "./FastestDet.onnx")

            # 导出torchscript模型
        if opt.torchscript:
            import copy

            model_cpu = copy.deepcopy(model).cpu()
            x = torch.rand(1, 3, cfg.input_height, cfg.input_width)
            mod = torch.jit.trace(model_cpu, x)
            mod.save("./FastestDet.pt")
            print("to convert torchscript to pnnx/ncnn: ./pnnx FastestDet.pt inputshape=[1,3,%d,%d]" % (
            cfg.input_height, cfg.input_height))
        '''
        import time

        # 模型推理
        start = time.perf_counter()
        preds, out_im = model(img)
        # 保存滤波器处理后的图片
        out_im.save(img_path.replace(img_root, filters_save_path))

        end = time.perf_counter()
        t = (end - start) * 1000.  #转换成ms毫秒
        print("forward time:%fms" % t)  # 推理时间


        # 特征图后处理  （获得的值[x1, y1, x2, y2, cls_score置信度, category]）
        output = handle_preds(preds, device, opt.thresh)

        # 加载label names
        LABEL_NAMES = []
        with open(cfg.names, 'r') as f:
            for line in f.readlines():
                LABEL_NAMES.append(line.strip())

        H, W, _ = ori_img.shape
        scale_h, scale_w = H / cfg.input_height, W / cfg.input_width

        # 绘制预测框
        for box in output[0]:
            print(box)
            box = box.tolist()

            obj_score = box[4]
            category = LABEL_NAMES[int(box[5])]  # 类别名称（下标==>名称）

            x1, y1 = int(box[0] * W), int(box[1] * H)
            x2, y2 = int(box[2] * W), int(box[3] * H)

            cv2.rectangle(ori_img, (x1, y1), (x2, y2), (255, 255, 0), 2)
            cv2.putText(ori_img, '%.2f' % obj_score, (x1, y1 - 5), 0, 0.7, (0, 255, 0), 2)
            cv2.putText(ori_img, category, (x1, y1 - 25), 0, 0.7, (0, 255, 0), 2)

        # cv2.imwrite("result.png", ori_img)
        cv2.imwrite(img_path.replace(img_root, dir_save_path), ori_img)

        # 将预测结果写入文件
        # 1)先获得测试的图片序号
        image_id = img_path.split("/")[-1].rstrip(".jpg")
        # 2）将每个图片的预测结果写入对应文件
        detection_path = 'map_out/detection_results'
        f = open(os.path.join(detection_path, image_id + ".txt"), "w")
        pt = []
        for box in output[0]:
            box = box.tolist()
            x1, y1, x2, y2 = box[:4]
            # x1y1x2y2 ==> xywh
            center_x, center_y = (x1 + x2) / 2, (y1 + y2) / 2
            w, h = x2 - x1, y2 - y1
            obj_score = box[4]
            cls_label = box[5]
            x11, y11 = x1 * W, y1 * H
            x22, y22 = x2 * W, y2 * H
            pt.append([cls_label, obj_score, x11, y11, x22, y22])
            # 写入文件
            f.write("%s %s %s %s %s %s\n" % (int(cls_label), obj_score, str(center_x), str(center_y), str(w), str(h)))
        f.close()
        pts.append(np.array(pt))

        # 获取gt数据
        gt_path = 'TT100K/test'
        f_gt = open(os.path.join(gt_path, image_id + ".txt"))
        gt = []
        for line in f_gt:  # 读取文件的每一行内容
            line = line.split()
            label = int(line[0])
            bcx, bcy = float(line[1]) * W, float(line[2]) * H
            bw, bh = float(line[3]) * W, float(line[4]) * H
            x1, y1 = bcx - 0.5 * bw, bcy - 0.5 * bh
            x2, y2 = bcx + 0.5 * bw, bcy + 0.5 * bh
            gt.append([label, x1, y1, x2, y2])

        gts.append(np.array(gt))

        totalTime += (end - start)


    # 3. 转换成coco格式，得到验证结果
    coco_evaluator = CocoDetectionEvaluator(cfg.names, device)
    print("----------------------------------map results-------------------------------------------------")
    mAP05 = coco_evaluator.coco_evaluate(gts, pts)
    # 输出最终的验证结果
    # print("mAP50=" % mAP05)

    # 输出FPS
    avgTime = totalTime / len(imgs_list)
    fps = 1.0 / avgTime
    print("fps= %.2f" % fps)
