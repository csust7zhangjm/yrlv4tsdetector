from timm.models.layers import DropPath, to_2tuple, trunc_normal_
from core.MFB import *


def autopad(k, p=None):
    if p is None:
        p = k // 2 if isinstance(k, int) else [x // 2 for x in k]
    return p

# 1*1 卷积
def conv1x1(in_planes: int, out_planes: int, stride: int = 1) -> nn.Conv2d:
    """1x1 convolution"""
    return nn.Conv2d(in_planes, out_planes, kernel_size=1, stride=1, bias=False)

# def shift(dim):
#     x_shift = [torch.roll(x_c, shift, dim) for x_c, shift in zip(xs, range(-self.pad, self.pad + 1))]
#     x_cat = torch.cat(x_shift, 1)
#     x_cat = torch.narrow(x_cat, 2, self.pad, H)
#     x_cat = torch.narrow(x_cat, 3, self.pad, W)
#     return x_cat

# shift操作
class shiftmlp(nn.Module):
    def __init__(self, in_features, hidden_features=None, out_features=None, act_layer=nn.GELU, drop=0., shift_size=5):
        super().__init__()
        out_features = out_features or in_features
        hidden_features = hidden_features or in_features
        self.dim = in_features
        self.fc1 = nn.Linear(in_features, hidden_features)
        self.dwconv = DWConv(hidden_features)
        self.act = act_layer()
        self.fc2 = nn.Linear(hidden_features, out_features)
        self.drop = nn.Dropout(drop)

        self.shift_size = shift_size
        self.pad = shift_size // 2

        self.apply(self._init_weights)

    def _init_weights(self, m):
        if isinstance(m, nn.Linear):
            trunc_normal_(m.weight, std=.02)
            if isinstance(m, nn.Linear) and m.bias is not None:
                nn.init.constant_(m.bias, 0)
        elif isinstance(m, nn.LayerNorm):
            nn.init.constant_(m.bias, 0)
            nn.init.constant_(m.weight, 1.0)
        elif isinstance(m, nn.Conv2d):
            fan_out = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
            fan_out //= m.groups
            m.weight.data.normal_(0, math.sqrt(2.0 / fan_out))
            if m.bias is not None:
                m.bias.data.zero_()

    #     def shift(x, dim):
    #         x = F.pad(x, "constant", 0)
    #         x = torch.chunk(x, shift_size, 1)
    #         x = [ torch.roll(x_c, shift, dim) for x_s, shift in zip(x, range(-pad, pad+1))]
    #         x = torch.cat(x, 1)
    #         return x[:, :, pad:-pad, pad:-pad]

    def forward(self, x, H, W):
        # pdb.set_trace()
        B, N, C = x.shape

        xn = x.transpose(1, 2).view(B, C, H, W).contiguous()
        xn = F.pad(xn, (self.pad, self.pad, self.pad, self.pad), "constant", 0)
        xs = torch.chunk(xn, self.shift_size, 1)
        x_shift = [torch.roll(x_c, shift, 2) for x_c, shift in zip(xs, range(-self.pad, self.pad + 1))]
        x_cat = torch.cat(x_shift, 1)
        x_cat = torch.narrow(x_cat, 2, self.pad, H)
        x_s = torch.narrow(x_cat, 3, self.pad, W)

        x_s = x_s.reshape(B, C, H * W).contiguous()
        x_shift_r = x_s.transpose(1, 2)

        x = self.fc1(x_shift_r)

        x = self.dwconv(x, H, W)
        x = self.act(x)
        x = self.drop(x)

        xn = x.transpose(1, 2).view(B, C, H, W).contiguous()
        xn = F.pad(xn, (self.pad, self.pad, self.pad, self.pad), "constant", 0)
        xs = torch.chunk(xn, self.shift_size, 1)
        x_shift = [torch.roll(x_c, shift, 3) for x_c, shift in zip(xs, range(-self.pad, self.pad + 1))]
        x_cat = torch.cat(x_shift, 1)
        x_cat = torch.narrow(x_cat, 2, self.pad, H)
        x_s = torch.narrow(x_cat, 3, self.pad, W)
        x_s = x_s.reshape(B, C, H * W).contiguous()
        x_shift_c = x_s.transpose(1, 2)

        x = self.fc2(x_shift_c)
        x = self.drop(x)
        return x


class shiftedBlock(nn.Module):
    def __init__(self, dim, num_heads, mlp_ratio=4., qkv_bias=False, qk_scale=None, drop=0., attn_drop=0.,
                 drop_path=0., act_layer=nn.GELU, norm_layer=nn.LayerNorm, sr_ratio=1):
        super().__init__()

        self.drop_path = DropPath(drop_path) if drop_path > 0. else nn.Identity()
        self.norm2 = norm_layer(dim)
        mlp_hidden_dim = int(dim * mlp_ratio)
        self.mlp = shiftmlp(in_features=dim, hidden_features=mlp_hidden_dim, act_layer=act_layer, drop=drop)
        self.apply(self._init_weights)

    def _init_weights(self, m):
        if isinstance(m, nn.Linear):
            trunc_normal_(m.weight, std=.02)
            if isinstance(m, nn.Linear) and m.bias is not None:
                nn.init.constant_(m.bias, 0)
        elif isinstance(m, nn.LayerNorm):
            nn.init.constant_(m.bias, 0)
            nn.init.constant_(m.weight, 1.0)
        elif isinstance(m, nn.Conv2d):
            fan_out = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
            fan_out //= m.groups
            m.weight.data.normal_(0, math.sqrt(2.0 / fan_out))
            if m.bias is not None:
                m.bias.data.zero_()

    def forward(self, x, H, W):
        # 残差连接
        x = x + self.drop_path(self.mlp(self.norm2(x), H, W))
        return x


# 深度可分离卷积
class DWConv(nn.Module):
    def __init__(self, dim=768):
        super(DWConv, self).__init__()
        self.dwconv = nn.Conv2d(dim, dim, 3, 1, 1, bias=True, groups=dim)

    def forward(self, x, H, W):
        B, N, C = x.shape
        x = x.transpose(1, 2).view(B, C, H, W)
        x = self.dwconv(x)
        x = x.flatten(2).transpose(1, 2)

        return x


# Encoding编码
class OverlapPatchEmbed(nn.Module):
    """ Image to Patch Embedding
    """

    def __init__(self, img_size=640, patch_size=7, stride=4, in_chans=512, embed_dim=768):
        super().__init__()
        img_size = to_2tuple(img_size)
        patch_size = to_2tuple(patch_size)

        self.img_size = img_size
        self.patch_size = patch_size
        self.H, self.W = img_size[0] // patch_size[0], img_size[1] // patch_size[1]
        self.num_patches = self.H * self.W
        self.proj = nn.Conv2d(in_chans, embed_dim, kernel_size=patch_size, stride=stride,
                              padding=(patch_size[0] // 2, patch_size[1] // 2))
        self.norm = nn.LayerNorm(embed_dim)

        self.apply(self._init_weights)

    def _init_weights(self, m):
        if isinstance(m, nn.Linear):
            trunc_normal_(m.weight, std=.02)
            if isinstance(m, nn.Linear) and m.bias is not None:
                nn.init.constant_(m.bias, 0)
        elif isinstance(m, nn.LayerNorm):
            nn.init.constant_(m.bias, 0)
            nn.init.constant_(m.weight, 1.0)
        elif isinstance(m, nn.Conv2d):
            fan_out = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
            fan_out //= m.groups
            m.weight.data.normal_(0, math.sqrt(2.0 / fan_out))
            if m.bias is not None:
                m.bias.data.zero_()

    def forward(self, x):
        x = self.proj(x)
        _, _, H, W = x.shape
        x = x.flatten(2).transpose(1, 2)
        x = self.norm(x)

        return x, H, W


class MLPBlock(nn.Module):
    def __init__(self, embed_dim, drop_path=0., sr_ratio=2, num_heads=1, img_size=640, patch_size=16, in_chans=3, mlp_ratio=4, qkv_bias=False, qk_scale=None, drop_rate=0.,
                 attn_drop_rate=0., drop_path_rate=0., norm_layer=nn.LayerNorm):
        # dpr:drop_path_rate
        super().__init__()
        self.norm = norm_layer(embed_dim)
        # dpr = [x.item() for x in torch.linspace(0, drop_path_rate, sum(depths))]
        self.block = nn.ModuleList([shiftedBlock(
            dim=embed_dim, num_heads=num_heads, mlp_ratio=1,qkv_bias=qkv_bias, qk_scale=qk_scale,
            drop=drop_rate, attn_drop=attn_drop_rate, drop_path=drop_path, norm_layer=norm_layer,
            sr_ratio=sr_ratio)])
        self.patch_embed = OverlapPatchEmbed(img_size=img_size, patch_size=3, stride=1, in_chans=in_chans,
                                             embed_dim=embed_dim)
        self.soft = nn.Softmax(dim=1)

    def forward(self, x):
        B = x.shape[0]

        ### Tokenized MLP
        # (1)encoding+GELU
        out, H, W = self.patch_embed(x)
        # (2) shifted MLP
        for i,blk in enumerate(self.block):
            out = blk(out, H, W)
        # (3) Norm
        out = self.norm(out)
        # (4) Reshape
        # (B,H,W,C) ==> (B,C,H,W)
        out = out.reshape(B, H, W, -1).permute(0, 3, 1, 2).contiguous()
        return out


class MPN(nn.Module):
    def __init__(self, embed_dims=[512, 256, 128], num_heads=1, sr_ratio=[2,2,2,2], depths=[1,1,1], drop_path_rate = 0.,
                 img_size=20, patch_size=16, in_chans=[512, 256, 128], mlp_ratio=4, qkv_bias=False, qk_scale=None,
                 drop_rate=0., attn_drop_rate=0.):
        super().__init__()

        dpr = [x.item() for x in torch.linspace(0, drop_path_rate, sum(depths))]

        # 800 ==> 100 / 50 / 25
        # 1024 ==> 128 / 64 / 32
        # 640 ==> 80 / 40 / 20
        # 构建MLP Block结构
        self.MlpB1 = MLPBlock(img_size=80, in_chans=in_chans[2], embed_dim=embed_dims[2], drop_path=dpr[0], sr_ratio=sr_ratio[0])
        self.MlpB2 = MLPBlock(img_size=40, in_chans=in_chans[1], embed_dim=embed_dims[1], drop_path=dpr[1], sr_ratio=sr_ratio[0])
        self.MlpB3 = MLPBlock(img_size=20, in_chans=in_chans[0], embed_dim=embed_dims[0], drop_path=dpr[2], sr_ratio=sr_ratio[0])

        # 1*1 卷积
        self.conv1 = ConvSiLU(in_chans[2], in_chans[1], kernel_size=1, stride=1, groups=in_chans[2])
        self.conv2 = ConvSiLU(in_chans[1], in_chans[0], kernel_size=1, stride=1, groups=in_chans[1])

        # 下采样
        self.dp1 = ConvSiLU(in_chans[1], in_chans[1], 3, stride=2, groups=in_chans[1])
        self.dp2 = ConvSiLU(in_chans[0], in_chans[0], 3, stride=2, groups=in_chans[0])

        # FA结构 (2c==>c)
        self.fa1 = FusionLayer(in_chans[1] * 2, in_chans[1])
        self.fa2 = FusionLayer(in_chans[0] * 2, in_chans[0])

    def forward(self, x):
        c3, c4, c5 = x
        # p3
        p3 = self.MlpB1(c3)

        # p4
        cm4 = self.dp1(self.conv1(p3))
        cat1 = torch.cat([cm4, c4], dim=1)
        cat1 = self.fa1(cat1)
        p4 = self.MlpB2(cat1)

        #p5
        cm5 = self.dp2(self.conv2(p4))
        # cm3 = self.dp1(self.conv1(p3))
        # cm3 = self.dp2(self.conv2(cm3))
        # cat2 = torch.cat([cm3, cm5, c5], dim=1)
        cat2 = torch.cat([cm5, c5], dim=1)
        cat2 = self.fa2(cat2)
        p5 = self.MlpB3(cat2)

        return p5




# if __name__ == '__main__':
# # #     x = torch.randn([1, 3, 608, 608])
# # #     backbone = EfficientRep(3, [64, 128, 256, 512, 1024], [1, 6, 12, 18, 6])
# # #     c3, c4, c5 = backbone(x)
#     mpn = MPN()
#     torch.save(mpn.state_dict(), "neck.pth")  #16MB


