import math
import argparse
from copy import copy

from PIL.ImagePath import Path
from tqdm import tqdm
from torch import optim
import torch.backends.cudnn as cudnn
import torch.nn as nn

from utils.datasets import *
from utils.evaluation import CocoDetectionEvaluator

from models.loss import DetectorLoss
from models.detector import Detector

import matplotlib.pyplot as plt

from MyLR import *

# 指定后端设备&CPU
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


# 设置随机种子
def set_random_seed(seed=0, deterministic=False, benchmark=False):
    random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    if deterministic:
        cudnn.deterministic = True
    if benchmark:
        cudnn.benchmark = True


# 绘制学习曲线，以确定模型的状况
def plot_my_lr_scheduler(y=[], epochs=300):
    # Plot LR simulating training for full epochs

    plt.plot(y, '.-', label='LR')
    plt.xlabel('epoch')
    plt.ylabel('LR')
    plt.grid()
    plt.xlim(0, epochs)
    plt.ylim(0)
    plt.savefig('LR.png', dpi=200)
    plt.close()



class TSDetection:
    def __init__(self):
        # 单GP训练
        os.environ['CUDA_VISIBLE_DEVICES'] = '0'
        # os.environ['CUDA_VISIBLE_DEVICES'] = '0, 1, 2, 3'  ##
        set_random_seed(0)
        # 指定训练配置文件
        parser = argparse.ArgumentParser()
        parser.add_argument('--yaml', type=str, default="configs/sign.yaml", help='.yaml config')
        parser.add_argument('--weight', type=str, default=None, help='.weight config')

        # resume
        # 若需要接着上次训练，则指定上次训练保存权重文件地址
        parser.add_argument('--resume', type=str, default='', help='resume from checkpoint')

        # 指定接着从哪个epoch数开始训练
        parser.add_argument('--start_epoch', default=1, type=int, help='start epoch')
        # 设置step_epoch
        parser.add_argument('--step_epoch', default=200, type=int, help='mid epoch')
        # training strategy
        parser.add_argument('--use_warm_up', action='store_true', default=True,
                            help='use warm up')


        opt = parser.parse_args()
        assert os.path.exists(opt.yaml), "请指定正确的配置文件路径"

        # 设置多卡训练
        # torch.cuda.set_device(opt.local_rank) ##

        # 解析yaml配置文件
        self.cfg = LoadYaml(opt.yaml)
        print(self.cfg)

        # 初始化模型结构
        self.model = Detector(self.cfg.category_num)
        # self.model = nn.DataParallel(self.model)  ##采用分布式训练
        if opt.weight is not None:
            print("load weight from:%s" % opt.weight)
            self.model = self.model.to(device)
            self.model.load_state_dict(torch.load(opt.weight))
        else:
            self.model = self.model.to(device)

        # # 打印网络各层的张量维度（这里会出错）
        # summary(self.model, input_size=(3, self.cfg.input_height, self.cfg.input_width))
        # 直接打印模型结构
        print(self.model)

        # 构建优化器
        print("use Adam optimizer")
        # AdamW对超参数更不敏感且收敛更快
        self.optimizer = optim.Adam(params=self.model.parameters(),
                                    lr=self.cfg.learn_rate
                                    # weight_decay=0.05,   ##
                                    )

        # 学习率衰减策略
        # 学习率下降策略换成CosineAnnealingLR 余弦退火调整学习率
        # self.scheduler = optim.lr_scheduler.CosineAnnealingLR(self.optimizer, T_max=100)

        # 定义损失函数
        self.loss_function = DetectorLoss(device)

        # 定义验证函数
        self.evaluation = CocoDetectionEvaluator(self.cfg.names, device)

        # 数据集加载
        val_dataset = TensorDataset(self.cfg.val_txt, self.cfg.input_width, self.cfg.input_height, False)
        train_dataset = TensorDataset(self.cfg.train_txt, self.cfg.input_width, self.cfg.input_height, True)

        self.batch_size = self.cfg.batch_size
        self.epoch_size = len(train_dataset) // self.batch_size
        # 验证集
        self.val_dataloader = torch.utils.data.DataLoader(val_dataset,
                                                          batch_size=self.cfg.batch_size,
                                                          shuffle=False,
                                                          collate_fn=collate_fn
                                                          # num_workers=8,
                                                          # drop_last=False,
                                                          # persistent_workers=True
                                                          )
        # 训练集
        self.train_dataloader = torch.utils.data.DataLoader(train_dataset,
                                                            batch_size=self.cfg.batch_size,
                                                            shuffle=True,
                                                            collate_fn=collate_fn,
                                                            num_workers=8,  ##
                                                            pin_memory=True,  ##节省资源
                                                            drop_last=True,
                                                            persistent_workers=True
                                                            )
        self.start_epoch = opt.start_epoch
        self.step_epoch = opt.step_epoch
        self.use_warm_up = opt.use_warm_up

        self.base_lr = self.cfg.learn_rate
        self.tmp_lr = self.base_lr

        # 断点训练
        if opt.resume != "":
            checkpoint = torch.load(opt.resume)
            self.model.load_state_dict(checkpoint['model'])
            self.optimizer.load_state_dict(checkpoint['optimizer'])
            self.tmp_lr = checkpoint['lr']
            opt.start_epoch = checkpoint['epoch'] + 1


    def train(self):
        # 迭代训练
        batch_num = 0
        print('Starting training for %g epochs...' % self.cfg.end_epoch)
        best_map = 0  # 记录最好结果
        # 开始训练
        for epoch in range(self.start_epoch, self.cfg.end_epoch + 1):
            self.model.train()
            pbar = tqdm(self.train_dataloader)
            #使用自己实现的余弦退火策略
            # step_epoch:200, end_epoch:250, base_lr:1e-3
            set_cos_lr(epoch, self.step_epoch, self.cfg.end_epoch, self.optimizer, self.base_lr)
            iter_i = 0
            for imgs, targets in pbar:
                # 数据预处理
                imgs = imgs.to(device).float() / 255.0
                targets = targets.to(device)
                # 使用warmup
                if self.use_warm_up:
                    set_warm_up(epoch, self.epoch_size, iter_i, self.optimizer, self.base_lr)
                iter_i += 1

                # reset gradient
                self.optimizer.zero_grad()

                # 模型推理
                preds = self.model(imgs)

                # loss计算
                box, obj, cls, total = self.loss_function(preds, targets)
                # 反向传播求解梯度
                total = total.requires_grad_()
                # 在这里注意：在进行梯度反向传播时要保证不是张量而是向量，采用对最终值进行.mean()或.sum()操作
                total.backward()

                # 更新模型参数
                self.optimizer.step()

                # 学习率预热 warmup（防止过拟合）
                # for g in self.optimizer.param_groups:
                #     warmup_num = 5 * len(self.train_dataloader)
                #     if batch_num <= warmup_num:
                #         scale = math.pow(batch_num / warmup_num, 4)
                #         g['lr'] = self.cfg.learn_rate * scale
                #     lr = g["lr"]

                # 获取此时的学习率
                tmp_lr = get_lr(self.optimizer)

                # 打印相关训练信息
                info = "Epoch:%d LR:%f box:%f Obj:%f Cls:%f Total:%f" % (
                    epoch, tmp_lr, box, obj, cls, total)
                pbar.set_description(info)
                batch_num += 1

            save_file = 'record.txt'

            # 模型验证及保存
            if epoch % 1 == 0 and epoch > 0:
                tmp_lr = get_lr(self.optimizer)
                # 模型评估
                self.model.eval()
                print("computer mAP...")
                mAP05 = self.evaluation.compute_map(self.val_dataloader, self.model)
                # 将每个epoch的数据写入文件
                with open(save_file, "a") as f:
                    f.write("epoch:" + str(epoch) + "  " + 'lr:' + str(tmp_lr) + '  ' + 'mAP05:' + str(mAP05))
                    f.write('\r\n')

                # 保存断点设置
                # 训练过程中保存模型参数
                save_files = {
                    'model': self.model.state_dict(),
                    'optimizer': self.optimizer.state_dict(),
                    'lr': tmp_lr,
                    'epoch': epoch
                }
                # torch.save(self.model.state_dict(), "checkpoint/weight_AP05:%f_%d-epoch.pth"%(mAP05, epoch))
                if mAP05 > best_map: #只保存map更好的结果
                    # 在test时只取部分权重['model']
                    torch.save(save_files, "checkpoint/weight_AP05:%f_%d-epoch.pth" % (mAP05, epoch))  ##
                    # torch.save(self.model.state_dict(), "weights/ckpt_{%f}.pth" % (mAP05))
                    best_map = mAP05

            # 学习率调整
            # self.scheduler.step()

        # 保存整个模型
        torch.save(self.model.state_dict(), "weights/last_ckpt_{%d}.pth" % (self.cfg.end_epoch))



if __name__ == "__main__":
    model = TSDetection()
    model.train()

    # # 绘制余弦退火学习率变化曲线
    # model = Detector(3)
    # min_lr = 1e-4
    # base_lr = 1e-3
    # start_epoch = 1
    # epochs = 300
    # optimizer = optim.Adam(model.parameters(), lr=base_lr)
    # # 使用自己实现的余弦退火策略
    # y = []
    # for epoch in range(start_epoch, epochs):
    #     y.append(cos_lr(optimizer, min_lr, base_lr, epoch, start_epoch, epochs))
    # plot_my_lr_scheduler(y)

