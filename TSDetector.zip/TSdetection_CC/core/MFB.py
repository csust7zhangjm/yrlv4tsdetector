import torch
import torch.nn as nn
import torch.nn.functional as F
from utils.conv import *

# 特征融合块
# 版本一（通道注意力：SE模块）
class FusionLayer(nn.Module):
    def __init__(self, inchannel, outchannel, reduction=16):
        super(FusionLayer, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Sequential(
            nn.Linear(inchannel, inchannel // reduction, bias=False), #不使用bias
            nn.ReLU(inplace=True),
            nn.Linear(inchannel // reduction, inchannel, bias=False),
            nn.Sigmoid()
        )
        self.outlayer = ConvPReLU(inchannel, outchannel, 1, 1, 0, bias=True, groups=outchannel)
        self.apply(self._init_weights)

    def forward(self, x):
        # concat
        b, c, _, _ = x.size()
        # squeeze
        y = self.avg_pool(x).view(b, c)
        # expand
        y = self.fc(y).view(b, c, 1, 1)
        # re_weight
        y = x * y.expand_as(x)
        y = y + x
        y = self.outlayer(y)
        return y

    def _init_weights(self, m):
        for m in self.modules():
            if isinstance(m, nn.Conv2d) or isinstance(m, nn.ConvTranspose2d):
                n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
                m.weight.data.normal_(0, math.sqrt(2. / n))
                if m.bias is not None:
                    m.bias.data.zero_()
            elif isinstance(m, nn.BatchNorm2d):
                m.weight.data.fill_(1)
                m.bias.data.zero_()
            elif isinstance(m, nn.Linear):
                m.weight.data.normal_(0, 0.01)

                # m.bias.data.zero_()


# 多尺度融合模块
class MultiScaleFusionBlock(nn.Module):
    def __init__(self, C):
        super(MultiScaleFusionBlock, self).__init__()
        self.flb = FusionLayer(3 * C, C)
        # 超参数
        self.beta1 = nn.Parameter(torch.Tensor([0.1]))
        self.beta2 = nn.Parameter(torch.Tensor([0.5]))

    def forward(self, input):
        B, C, H, W = input.shape
        # 自适应池化
        adavg_pool1 = nn.AdaptiveAvgPool2d((int(H * self.beta1), int(W * self.beta1)))  # F.adaptive_avg_pool2d()
        adavg_pool2 = nn.AdaptiveAvgPool2d((int(H * self.beta2), int(W * self.beta2)))
        input2 = adavg_pool1(input)
        input3 = adavg_pool2(input)
        # 上采样
        up1 = F.interpolate(input2, size=(H,W), mode ='bilinear', align_corners=True)
        up2 = F.interpolate(input3, size=(H,W), mode ='bilinear', align_corners=True)
        # 融合结构
        input_concat = torch.cat([input, up1, up2], dim=1)
        output = self.flb(input_concat)
        return output


# if __name__ =='__main__':
#     mfb = MultiScaleFusionBlock(128)
#     # x = torch.randn(1, 1, 640, 640)
#     # y = mfb(x, 0.2, 0.6)
#     # print(y.shape) #1*1*640*640
#     torch.save(mfb.state_dict(), "neck.pth")  # 0.077MB


# 空间信息聚合模块：增强特征金字塔的特征融合SIA
class SIA(nn.Module):
    def __init__(self, inchannel, outchannel, reduction=16):
        super().__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.conv11 = nn.Conv2d(inchannel, inchannel, 1)
        self.sigmoid = nn.Sigmoid()
        self.outlayer = ConvPReLU(inchannel, outchannel, 1, 1, 0, bias=True, groups=outchannel)
       # self.conv12 = nn.Conv2d(inchannel, outchannel, 1)
        self.apply(self._init_weights)

    def forward(self, x):
        # concat
        b, c, _, _ = x.size()
        # squeeze
        y = self.sigmoid(self.conv11(self.avg_pool(x)))   #[b,c,1,1]
        # re_weight
        y = x * y
        y = y + x
        y = self.outlayer(y)
       # y = self.conv12(y)
        return y

    def _init_weights(self, m):
        for m in self.modules():
            if isinstance(m, nn.Conv2d) or isinstance(m, nn.ConvTranspose2d):
                n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
                m.weight.data.normal_(0, math.sqrt(2. / n))
                if m.bias is not None:
                    m.bias.data.zero_()
            elif isinstance(m, nn.BatchNorm2d):
                m.weight.data.fill_(1)
                m.bias.data.zero_()
            elif isinstance(m, nn.Linear):
                m.weight.data.normal_(0, 0.01)
                # m.bias.data.zero_()


# MSFFM: multi-scale feature fusion module
class MSFFM(nn.Module):
    def __init__(self, inchannel, outchannel):
        super().__init__()
        self.conv33 = nn.Conv2d(inchannel, outchannel, 3, padding=1, stride=1)

    def forward(self, x):
        ci, cj = x
        b, c, h, w = ci.shape
        # 3*3 conv
        ci = self.conv33(ci)
        cj = self.conv33(cj)
        # reshape
        p = ci.reshape(b, c, h*w)
        q = cj.reshape(b, c, h*w)
        # 1.transpose
        q = torch.transpose(q, 1, 2)  #(b, c, n) ==> (b, n, c),其中 n=h*w
        # multi
        s = torch.matmul(q, p)  #(n*c)*(c*n) = n*n
        # 2.transpose
        q = torch.transpose(q, 1, 2)  #(b, n, c) ==> (b, c, n)
        l = torch.matmul(q, s)  #(c*n)*(n*n) == c*n
        l = l.reshape(b, c, h, w)   #c*n ==> c*h*w
        # add
        out = cj + l
        return out



# if __name__ == '__main__':
#     x = torch.randn([2, 512, 19, 19])
#     y = torch.randn([2, 512, 19, 19])
#     msffm = MSFFM(512, 512)
#     out = msffm([x, y])
#     print(out.shape)








