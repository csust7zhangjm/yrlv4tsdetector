import numpy as np
import torch
import torch.nn as nn
import torchvision
import time
import math
from torchvision.transforms import transforms
import torch.nn.functional as F
import cv2
# from filters import *
from core.config import cfg
from core.filters import *
from utils.conv import *


# CNN-PP Module
class extract_parameters(nn.Module):
    def __init__(self, cfg, init_weights=True):
        super().__init__()
        channel = cfg.cnnpp_channel   #16
        output_dim = cfg.num_filter_parameters   #10
        # 5 * conv
        self.conv1 = ConvLeaky(3, channel, 3, downsample=True)      # (3, 16, (3,3))
        self.conv2 = ConvLeaky(channel, channel * 2, 3, groups=channel, downsample=True)  # (16, 32, (3,3))
        self.conv3 = ConvLeaky(channel * 2, channel * 2, 3, groups=channel*2, downsample=True)  # (32, 32, (3,3))
        self.conv4 = ConvLeaky(channel * 2, channel * 2, 3, groups=channel*2, downsample=True)  # (32, 32, (3,3))
        self.conv5 = ConvLeaky(channel * 2, channel * 2, 3, groups=channel*2, downsample=True)  # (32, 32, (3,3))
        # 2 * fc
        self.fc1 = nn.Linear(2048, 2048)  #(2048, 2048)
        self.fc2 = nn.Linear(2048, output_dim)  # (2048, 18)
        if init_weights:
            self._initialize_weights()

    def forward(self, x):
        x = self.conv1(x)  # 1, 16, 128, 128
        x = self.conv2(x)  # 1, 32, 64, 64
        x = self.conv3(x)  # 1, 32, 32, 32
        x = self.conv4(x)  # 1, 32, 16, 16
        x = self.conv5(x)  # 1, 32, 8, 8
        # x = self.conv5(self.conv4(self.conv3(self.conv2(self.conv1(x)))))
        # 这里要reshape成最后的B, C * H * W = 2048
        x = x.reshape(-1, 2048)
        output = self.fc2(self.fc1(x))
        return output

    def _initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d): #是卷积层
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')  #kaiming正态分布初始化
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
                elif isinstance(m, nn.Linear): #是全连接层
                    nn.init.normal_(m.weight, 0, 0.01)
                    nn.init.constant_(m.bias, 0)

class extract_parameters_2(nn.Module):
    def __init__(self, cfg, init_weights=True):
        super().__init__()
        channel = cfg.cnnpp_channel  #16
        output_dim = cfg.num_filter_parameters   #18
        # 5 * conv
        # (256,256,3) ==> (128,128,16)
        self.conv1 = ConvLeaky(3, channel, 4, downsample=True)      # (3, 16, (4,4))
        # (128,128,16) ==> (64,64,32)
        self.conv2 = ConvLeaky(channel, channel * 2, 4, downsample=True)  # (16, 32, (4,4))
        # (64,64,32) ==> (32,32,64)
        self.conv3 = ConvLeaky(channel * 2, channel * 4, 4, downsample=True)  # (32, 64, (4,4))
        # (32,32,64) ==> (16,16,128)
        self.conv4 = ConvLeaky(channel * 4, channel * 8, 3, downsample=True)  # (64, 128, (4,4))
        # (16,16,128) ==> (8,8,256)
        self.conv5 = ConvLeaky(channel * 8, channel * 16, 3, downsample=True)  # (128, 256, (4,4))
        # fc
        self.fc = nn.Linear(4096, output_dim)  #(4096, 18)
        if init_weights:
            self._initialize_weights()

    def forward(self, x):
        x = self.conv1(x)
        x = self.conv2(x)
        x = self.conv3(x)
        x = self.conv4(x)
        x = self.conv5(x)  # 1 8 8 256
        # 这里要reshape成最后的B, C * H * W
        x = x.reshape(-1, 4096)
        output = self.fc(x)
        return output

    def _initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d): #是卷积层
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')  #kaiming正态分布初始化
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
                elif isinstance(m, nn.Linear): #是全连接层
                    nn.init.normal_(m.weight, 0, 0.01)
                    nn.init.constant_(m.bias, 0)


# 预测滤波器参数
class FiltersModule(nn.Module):
    def __init__(self):
        super().__init__()
        # 搭建CNN-PP网络
        self.extract = extract_parameters(cfg)

    def Resize(self, x):
        bs, c, h, w = x.shape[0], x.shape[1], x.shape[2], x.shape[3]
        # x = x.squeeze(0)  #只有维度为1时才会去掉
        resize = transforms.Compose([transforms.ToPILImage(),
                                     transforms.Resize([256, 256]),
                                     transforms.ToTensor()
                                    ])
        img = []
        for i in range(bs):
            im = x[i, :, :, :]
            im = resize(im)
            im = im.unsqueeze(0)
            # print(im.shape)   # [1,3,256,256]
            img.append(im)
        out = torch.cat(img, dim=0)
        # x = resize(x)
        return out

    def forward(self, x):
        low_res = self.Resize(x)
        low_res = low_res.cuda(0)

        # 构建滤波器参数预测网络
        out = self.extract(low_res)
        out = out.squeeze(0)
        return out








