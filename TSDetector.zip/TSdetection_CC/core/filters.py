import torch
import torch.nn as nn
import torch.nn.functional as F
import cv2
import math
import numpy as np
from PIL import Image


# 1. 像素级滤波器
# 1.1 WB（white balance）白平衡滤波器  (0-2)
class ImprovedWhiteBalanceFilter(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, x, param):
        param = param.view(-1, 3, 1, 1)
        return x * param


# 1.2 Gamma 灰度系数滤波器  (0-2)
class GammaFilter(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, x, param):
        a, b = param[0], param[1]
        return a * x + b

# 使用线性变换
def GammaFilter2(img, param):
    a,b = param[0], param[1]
    return a*img+b


# 1.3 Contrast 对比度滤波器 (0-1)
class ContrastFilter(nn.Module):
    def __init__(self):
        super().__init__()
        self.rgb2lum = nn.Parameter(torch.Tensor([0.27, 0.67, 0.06]).view(1, 3, 1, 1), requires_grad=False)

    def lerp(self, a, b, l):
      return (1 - l) * a + l * b

    def forward(self, x, param):
        param = param.reshape(-1, 1, 1, 1)
        rgb = self.rgb2lum * x
        # 亮度函数
        luminance = torch.clamp(torch.clamp(rgb, 0.0), 1.0)
        # 对比度增强
        contrast_lum = -torch.cos(math.pi * luminance) * 0.5 + 0.5
        # 增强函数
        contrast_image = x / (luminance + 1e-6) * contrast_lum
        out = self.lerp(x, contrast_image, param)
        return out


# 1.4 Tone 色调滤波器 (0-2)
class ToneFilter(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, x, param):
        param = param.view(-1, 8, 1, 1)  #[2,8,1,1]
        # print(param.shape)
        # print(x.shape)
        tone_curve = param
        tone_curve_sum = torch.sum(tone_curve, 1) + 1e-30  #[2,1,1]
        tone_curve_sum = tone_curve_sum.unsqueeze(-1)
        curve_steps = 8
        total_image = x * 0
        for i in range(curve_steps):
            # clip_by_value(t, t_min, t_max)：可以将一个张量中的数值限制在一个范围之内
            total_image += torch.clamp(x - 1.0 * i / curve_steps, 0, 1.0 / curve_steps) \
                           * tone_curve[:, i:i+1, :, :]
        # print(total_image.shape)
        total_image *= curve_steps / tone_curve_sum
        # print(total_image.shape)
        img = total_image
        return img


# 1.5 Luminance 亮度滤波器 (0-1)
class LumFilter(nn.Module):
    def __init__(self):
        super().__init__()
        self.rgb2lum = nn.Parameter(torch.Tensor([0.27, 0.67, 0.06]).view(1, 3, 1, 1), requires_grad=False)

    def lerp(self, a, b, l):
      return (1 - l) * a + l * b

    def forward(self, x, param):
        param = param.view(-1, 1, 1, 1)
        luminance = self.rgb2lum * x
        return self.lerp(x, luminance, param)


# 1.6 Exposure 曝光滤波器 (0-1)
class ExposureFilter(nn.Module):
    def __init__(self):
        super().__init__()
        self.ex = nn.Parameter(torch.log(torch.Tensor([2])), requires_grad=True)

    def forward(self, x, param):
        param = param.view(-1, 1, 1, 1)
        x = x * torch.exp(param * self.ex)
        return x


# 1.7 Saturation 饱和度滤波器 (0-1)
class SaturationFilter(nn.Module):
    def __init__(self):
        super().__init__()
        self.eps = 1e-8

    def rgb_to_hsv(self, img):
        hue = torch.Tensor(img.shape[0], img.shape[2], img.shape[3]).to(img.device)

        hue[img[:, 2] == img.max(1)[0]] = 4.0 + ((img[:, 0] - img[:, 1]) / (img.max(1)[0] - img.min(1)[0] + self.eps))[
            img[:, 2] == img.max(1)[0]]
        hue[img[:, 1] == img.max(1)[0]] = 2.0 + ((img[:, 2] - img[:, 0]) / (img.max(1)[0] - img.min(1)[0] + self.eps))[
            img[:, 1] == img.max(1)[0]]
        hue[img[:, 0] == img.max(1)[0]] = (0.0 + ((img[:, 1] - img[:, 2]) / (img.max(1)[0] - img.min(1)[0] + self.eps))[
            img[:, 0] == img.max(1)[0]]) % 6

        hue[img.min(1)[0] == img.max(1)[0]] = 0.0
        hue = hue / 6

        saturation = (img.max(1)[0] - img.min(1)[0]) / (img.max(1)[0] + self.eps)
        saturation[img.max(1)[0] == 0] = 0

        value = img.max(1)[0]

        hue = hue.unsqueeze(1)
        saturation = saturation.unsqueeze(1)
        value = value.unsqueeze(1)
        hsv = torch.cat([hue, saturation, value], dim=1)
        return hsv

    def hsv_to_rgb(self, hsv):
        h, s, v = hsv[:, 0, :, :], hsv[:, 1, :, :], hsv[:, 2, :, :]
        # 对出界值的处理
        h = h % 1
        s = torch.clamp(s, 0, 1)
        v = torch.clamp(v, 0, 1)

        r = torch.zeros_like(h)
        g = torch.zeros_like(h)
        b = torch.zeros_like(h)

        hi = torch.floor(h * 6)
        f = h * 6 - hi
        p = v * (1 - s)
        q = v * (1 - (f * s))
        t = v * (1 - ((1 - f) * s))

        hi0 = hi == 0
        hi1 = hi == 1
        hi2 = hi == 2
        hi3 = hi == 3
        hi4 = hi == 4
        hi5 = hi == 5

        r[hi0] = v[hi0]
        g[hi0] = t[hi0]
        b[hi0] = p[hi0]

        r[hi1] = q[hi1]
        g[hi1] = v[hi1]
        b[hi1] = p[hi1]

        r[hi2] = p[hi2]
        g[hi2] = v[hi2]
        b[hi2] = t[hi2]

        r[hi3] = p[hi3]
        g[hi3] = q[hi3]
        b[hi3] = v[hi3]

        r[hi4] = t[hi4]
        g[hi4] = p[hi4]
        b[hi4] = v[hi4]

        r[hi5] = v[hi5]
        g[hi5] = p[hi5]
        b[hi5] = q[hi5]

        r = r.unsqueeze(1)
        g = g.unsqueeze(1)
        b = b.unsqueeze(1)
        rgb = torch.cat([r, g, b], dim=1)
        return rgb

    def forward(self, x, param):
        param = param.view(-1, 1, 1, 1)
        img = torch.clamp(x, max=1.0)  # [1, 3, 480, 848]
        hsv = self.rgb_to_hsv(img)  # [1,3,480,848]
        s = hsv[:, 1:2, :, :]  # [1,3,480,848]
        v = hsv[:, 2:3, :, :]  # [1,3,480,848]
        # EnhancedS(s, v) = s + (1-s)*(0.5- |0.5-v|)*0.8
        enhanced_s = s + (1 - s) * (0.5 - torch.abs(0.5 - v)) ** 0.8  # [1,1,480,848]
        hsv1 = torch.cat([hsv[:, 0:1, :, :], enhanced_s, hsv[:, 2:, :, :]], dim=1)  # [1,3,480,848]
        full_color = self.hsv_to_rgb(hsv1)  # [1,3,480,848]
        color_param = param
        img_param = 1.0 - param
        return img * img_param + full_color * color_param


# 2. Sharpen 锐化滤波器 (0-3)
# 高斯滤波器（采用二维高斯函数）
class SharpenFilter(nn.Module):
    def __init__(self):
        super().__init__()
        kernel_i = self.make_gaussian_2d_kernel(25)  # 25*25的矩阵    # 5/7/13/25
        kernel_i = torch.FloatTensor(kernel_i).expand(3, 3, 25, 25)
        self.weight = nn.Parameter(data=kernel_i, requires_grad=False)
        self.bias = nn.Parameter(data=torch.zeros(3), requires_grad=False)

    def make_gaussian_2d_kernel(self, ksize=13, sigma=5):
        if sigma <= 0:
            # 根据 kernelsize 计算默认的 sigma
            sigma = 0.3 * ((ksize - 1) * 0.5 - 1) + 0.8
        center = ksize // 2
        xs = (np.arange(ksize, dtype=np.float32) - center) # 元素与矩阵中心的横向距离
        kernel1d = np.exp(-(xs ** 2) / (2 * sigma ** 2)) # 计算一维卷积核
        # 根据指数函数性质，利用矩阵乘法快速计算二维卷积核
        kernel = kernel1d[..., None] @ kernel1d[None, ...]
        kernel = torch.from_numpy(kernel)
        kernel = kernel / kernel.sum() # 归一化
        return kernel

    def forward(self, x, param):
        param = param.view(-1, 1, 1, 1)
        # print(kernel_i.shape)    #[3, 3, 25, 25]
        # 包装成可学习的，但是require_grad=False就不会求导
        # 使用高斯滤波器
        output = F.conv2d(x, self.weight, bias=self.bias, padding=(self.weight.shape[2] // 2, self.weight.shape[3] // 2), stride=1)
        # 公式：output = img + param*(img - Gau(x))
        img_out = (x - output) * param + x
       # img_out = (img - output) * 2.5 + img
        return img_out[:, :, :, :]


# 3. 去雾滤波器  #(0-1)
class DefogFilter(nn.Module):
    def __init__(self):
        super().__init__()

    # 1）暗通道
    def DarkChannel(self, img):
        # b, g, r = cv2.split(im)
        # dc = cv2.min(cv2.min(r, g), b)
        b = img[:, 0:1, :, :]
        g = img[:, 1:2, :, :]
        r = img[:, 2:3, :, :]
        dc = torch.minimum(torch.minimum(b, g), r)
        return dc   #[b,1,480,848]

    # 2）计算全球大气光A
    def AtmLight(self, img, dark):
       # print(img.shape)  #[b,3,h,w]
        b, c, h, w = img.shape   #w:848, h:480
        imsz = h * w   #imsz: 407040
        numpx = int(max(math.floor(imsz / 1000), 1))  #numpx:407
        darkvec = dark.reshape(imsz*b, -1)  #(h*w*b, 1)
        imvec = img.reshape(imsz*b, c)   #(h*w*b, c)

        indices = darkvec.argsort(0)   #(h*w*c,1)
        indices = indices[(imsz - numpx):imsz]  #(h*w*c/1000,1)

        atmsum = torch.zeros([1, c])  #(1,c)
        atmsum = atmsum.cuda(0)
        for ind in range(1, numpx):  #循环407次
            atmsum = atmsum + imvec[indices[ind]]
        A = atmsum / numpx  #[1,c]
        A = A.unsqueeze(-1).unsqueeze(-1)
        return A   #[1,3,1,1]

    # 3）计算IcA
    def DarkIcA(self, img, A, eps=1e-8):
        im3 = torch.zeros((img.shape))
        im3 = im3.cuda(0)
        for i in range(0, 3):
            im3[:, i, :, :] = img[:, i, :, :] / (A[:, i, :, :] + eps)
        return self.DarkChannel(im3)

    def forward(self, x, param):
        param = param.view(-1, 1, 1, 1)
        dc = self.DarkChannel(x) #[b,1,h,w]
        defog_A = self.AtmLight(x, dc) #[1,c,1,1]
        IcA = self.DarkIcA(x, defog_A) #[b,1,h,w]
        # 计算 t(x)
        tx = 1 - param * IcA  #[b,1,h,w]
        # tx = 1 - 0.5*IcA
        tx = torch.clamp(tx, min=0.01)
        out = (x - defog_A) / tx + defog_A
        return out  # [b,c,h,w]]
