import torch
import torch.nn as nn

from models.head import DetectHead

from fvcore.nn import FlopCountAnalysis, parameter_count_table
from torchsummary import summary

from torchstat import stat
from core.filters import *
from core.FiltersModule import *

from models.MLP_backbone import *
from models.neck import *
from models.decoder import *


class Detector(nn.Module):
    def __init__(self, category_num, out_channel=512):
        super(Detector, self).__init__()
        # 0) filters
        self.exposure = ExposureFilter()  # 曝光
        self.tone = ToneFilter()  # 色调（chromaticity）
        self.luminance = LumFilter()  # 亮度（intensity）

        # 滤波器网络
        self.cnnpp = FiltersModule()

        # 1) backbone
        self.backbone = UNext()

        # 2) neck
        self.neck = MPN()

        # 3) head
        self.out_channel = out_channel
        self.decoder = DilatedEncoder(self.out_channel)
        self.detect_head = DetectHead(self.out_channel, category_num)

        self.toPIL = transforms.ToPILImage()

    def forward(self, x):
        # （1）数据增强
        out = self.cnnpp(x)  # [10]

        # 滤波器变换
        x = self.exposure(x, torch.sigmoid(out[0]))  # x1
        # print('--------------exposure-------------------')

        x = self.tone(x, torch.sigmoid(out[1:9]) * 2)  # x2、x3、x4、x5、x6、x7、x8、x9
        # print('--------------tone-------------------')

        x = self.luminance(x, torch.sigmoid(out[9]))  # x10
        # print('--------------luminance-------------------')

        # print(x.shape)  # [b, 3, 608, 608] 恢复原来的输入大小

        # print("-------------------------filter Module----------------------------")
        # 保存经过滤波器处理的图片
        # out_im = self.toPIL(x.squeeze(0))

        # （2）特征提取
        p5 = self.neck(self.backbone(x))


        # （3）检测
        return self.detect_head(self.decoder(p5))







