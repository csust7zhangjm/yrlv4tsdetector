# neck

import torch
import torch.nn as nn
from utils.conv import *


class Bottleneck(nn.Module):

    def __init__(self,
                 in_channels: int = 512,
                 mid_channels: int = 128,
                 dilation: int = 1):
        super(Bottleneck, self).__init__()
        self.combine = nn.Sequential(
            ConvReLU(in_channels, mid_channels, 1, padding=0),
            ConvReLU(mid_channels, mid_channels, 3, padding=dilation, dilation=dilation),
            ConvReLU(mid_channels, in_channels, 1, padding=0))

    def forward(self, x):
        identity = x
        x = self.combine(x)
        out = x + identity
        return out

# dilated Encoder1
# 串联的空间卷积
class DilatedEncoder(nn.Module):
    def __init__(self, in_channels, block_dilations=[2, 4, 6, 8]):
        super().__init__()
        self.in_channel = in_channels
        self.block_dilation = block_dilations
        self.num_residual_blocks = len(self.block_dilation)
        self.bottleneck = nn.Sequential(
            Bottleneck(dilation=self.block_dilation[0]),
            Bottleneck(dilation=self.block_dilation[1]),
            Bottleneck(dilation=self.block_dilation[2]),
            Bottleneck(dilation=self.block_dilation[3])
        )

    def forward(self, x):
        # num_residual_blocks = len(self.block_dilation)
        # for i in range(num_residual_blocks):
        #     x = self.bottleneck(x)
        x = self.bottleneck(x)
        return x


# ASPP结构
# 并联的空洞卷积结构
class ASPP(nn.Module):
    def __init__(self, in_channel=512, depth=256):
        super(ASPP, self).__init__()
        # global average pooling : init nn.AdaptiveAvgPool2d ;also forward torch.mean(,,keep_dim=True)
        self.mean = nn.AdaptiveAvgPool2d((1, 1))
        self.conv = nn.Conv2d(in_channel, depth, 1, 1)
        # k=1 s=1 no pad
        self.atrous_block1 = nn.Conv2d(in_channel, depth, 1, 1)
        self.atrous_block6 = nn.Conv2d(in_channel, depth, 3, 1, padding=6, dilation=6)
        self.atrous_block12 = nn.Conv2d(in_channel, depth, 3, 1, padding=12, dilation=12)
        self.atrous_block18 = nn.Conv2d(in_channel, depth, 3, 1, padding=18, dilation=18)
        self.conv_1x1_output = nn.Conv2d(depth * 5, in_channel, 1, 1)

    def forward(self, x):
        size = x.shape[2:]

        image_features = self.mean(x)
        image_features = self.conv(image_features)
        image_features = F.interpolate(image_features, size=size, mode ='bilinear', align_corners=True)

        atrous_block1 = self.atrous_block1(x)

        atrous_block6 = self.atrous_block6(x)

        atrous_block12 = self.atrous_block12(x)

        atrous_block18 = self.atrous_block18(x)

        net = self.conv_1x1_output(torch.cat([image_features, atrous_block1, atrous_block6,
                                              atrous_block12, atrous_block18], dim=1))
        return net


# dilated Encoder2
class DilatedEncoder2(nn.Module):
    def __init__(self):
        super().__init__()


    def forward(self, x):
        pass






#
# if __name__ == '__main__':
#     x = torch.randn([1, 512, 19, 19])
#     dilated = DilatedEncoder(512)
#     out = dilated(x)   #[1, 512, 19, 19]
#     torch.save(dilated.state_dict(), "decoder.pth")  #4M
