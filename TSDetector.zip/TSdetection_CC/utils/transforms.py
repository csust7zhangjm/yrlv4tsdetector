import os
import cv2
import numpy as np
from torchvision import transforms

import torch
import random
random.seed(10)  #设置随机种子
os.environ['PYTHONHASHSEED'] = str(10)

from PIL import Image, ImageDraw
from utils.tool import *


# 位置变换，降低模型对目标位置的敏感性
# xywh
# 随机裁剪
def random_crop(image, boxes):
    height, width, _ = image.shape
    # random crop image
    cw, ch = random.randint(int(width * 0.75), width), random.randint(int(height * 0.75), height)
    cx, cy = random.randint(0, width - cw), random.randint(0, height - ch)

    roi = image[cy:cy + ch, cx:cx + cw]
    roi_h, roi_w, _ = roi.shape

    output = []
    for box in boxes:
        index, category = box[0], box[1]
        bx, by = box[2] * width, box[3] * height
        bw, bh = box[4] * width, box[5] * height

        bx, by = (bx - cx) / roi_w, (by - cy) / roi_h  ##
        bw, bh = bw / roi_w, bh / roi_h  ##

        output.append([index, category, bx, by, bw, bh])

    output = np.array(output, dtype=float)

    return roi, output

# 随机翻转（水平与竖直）
def random_flip_lr(image, boxes):
    if random.randint(1, 10) % 2 == 0:
        image = np.fliplr(image)
        # 在进行仿射变换之后会忽略一些边界框，如果没有边界框信息就可以跳过了，如果有则进行处理
        nl = len(boxes) # number of labels
        if nl:
            # Normalize coordinates 0-1： 归一化处理
            boxes[:, [2, 4]] /= image.shape[0]   #height
            boxes[:, [1, 3]] /= image.shape[1]   #width
            # 随机水平翻转
            boxes[:, 2] = 1 - boxes[:, 2]  #1 - center_x
    return image, boxes

def random_flip_ud(image, boxes):
    if random.randint(1, 10) % 2 == 0:
        image = np.flipud(image)
        nl = len(boxes)
        if nl:
            boxes[:, [2, 4]] /= image.shape[0]   #height
            boxes[:, [1, 3]] /= image.shape[1]   #width
            # 随机上下翻转
            boxes[:, 3] = 1 - boxes[:, 3]  #1 - center_y
    return image, boxes



# -------------------------------------------------------------------------------------------------------------
# 调整亮度、对比度、饱和度和色调，降低模型对色彩的敏感度
# 只需要对图片进行处理，不需要对label进行处理

# 亮度
# 把图像加减某个值
def random_brightness(img, delta=0.2):
    img += random.uniform(-delta, delta)
    return img

# 对比度
# 图片像素点随机乘以某个值(0.5, 1.5)
def random_contrast(img, alpha_low=0.5, alpha_up=1.5):
    img *= random.uniform(alpha_low, alpha_up)
    img = img.clip(min=0, max=255)
    return img

# 饱和度
# 中间的色彩通道乘以某个值
def random_saturation(img, alpha_low=0.5, alpha_up=1.5):
    hsv_img = cv2.cvtColor(img.astype(np.float32), cv2.COLOR_BGR2HSV)
    hsv_img[..., 1] *= random.uniform(alpha_low, alpha_up)
    img = cv2.cvtColor(hsv_img, cv2.COLOR_HSV2BGR)
    # img[:, :, 1] *= random.uniform(alpha_low, alpha_up)
    return img

# 色度
def random_hsv(image, hgain=0.5, sgain=0.5, vgain=0.5):
    """
    HSV color-space augmentation
    :param image:       待增强的图片
    :param hgain:       HSV 中的 h 扰动系数，yolov5：0.015
    :param sgain:       HSV 中的 s 扰动系数，yolov5：0.7
    :param vgain:       HSV 中的 v 扰动系数，yolov5：0.4
    :return:
    """
    if hgain or sgain or vgain:
        # 随机取-1到1三个实数，乘以 hsv 三通道扰动系数
        # r:【1-gain ~ 1+gain】
        r = np.random.uniform(-1, 1, 3) * [hgain, sgain, vgain] + 1  # random gains

        image_hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
        # cv2.split：通道拆分
        # h:[0~180], s:[0~255], v:[0~255]
        hue, sat, val = cv2.split(image_hsv)
        dtype = image.dtype  # uint8

        # 构建查找表
        x = np.arange(0, 256, dtype=r.dtype)
        lut_hue = ((x * r[0]) % 180).astype(dtype)
        lut_sat = np.clip(x * r[1], 0, 255).astype(dtype)
        lut_val = np.clip(x * r[2], 0, 255).astype(dtype)

        # cv2.LUT：dst(I) = lut(src(I) + d)，d为常数0 / 128
        hue = cv2.LUT(hue, lut_hue)
        sat = cv2.LUT(sat, lut_sat)
        val = cv2.LUT(val, lut_val)

        # 通道合并
        image_hsv = cv2.merge((hue, sat, val)).astype(dtype)

        # 将 hsv 格式转为 BGR 格式
        image_dst = cv2.cvtColor(image_hsv, cv2.COLOR_HSV2BGR)
        return image_dst
    else:
        return image


# 对图片进行归一化处理
def normalize(img, mean, std):
   # mean = np.array(mean, dtype=np.float32).reshape(1, 1, 3) / 255
   # std = np.array(std, dtype=np.float32).reshape(1, 1, 3) / 255
    img = (img - mean) / std
    return img


# 颜色的转换
def ColorConversion(img):
    cfg = LoadYaml("configs/sign.yaml")
    # PIL ==> Tensor
    # <numpy.ndarray> (800, 1360, 3) ==> <torch.Tensor> [3, 800, 1360]
    # image = transforms.functional.to_tensor(img)
    # image = Image.fromarray(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
    # if random.randint(1, 10) % 2 == 0:
    #    img = random_brightness(img, cfg.brightess)
    # if random.randint(1, 10) % 2 == 0:
    #     img = random_saturation(img, cfg.saturation[0], cfg.saturation[1])
    # if random.randint(1, 10) % 2 == 0:
    #     img = random_contrast(img, cfg.contrast[0], cfg.contrast[1])
    # if random.randint(1, 10) % 2 == 0:
    img = random_hsv(img, cfg.hsv[0], cfg.hsv[1], cfg.hsv[2])
    # image = normalize(image, cfg.normalize[0], cfg.normalize[1])
    # out_img = Image.fromarray(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
    #out_img = transforms.functional.to_tensor(image)
    #out_img = image.permute(1, 2, 0)
    return img

# if __name__ == '__main__':
#     path = '../GTSDB/train/00001.jpg'
#     img = cv2.imread(path)
#     print(type(img))
#     print(ColorConversion(img))
