import torch
import torch.nn.functional as F
import torch.nn as nn
from torch.autograd import Variable


# 普通版focal loss
class FocalLoss(nn.Module):
    def __init__(self, gamma=2.0, alpha=0.25):
        super().__init__()
        self.bce = F.binary_cross_entropy_with_logits
        self.gamma = gamma
        self.alpha = alpha

    def forward(self, pred, target, reduction='mean'):
        # pred: [n, 3]    target：[n]
        pred_sigmoid = pred.sigmoid()  # [n,3]
        B, C = pred.shape[0], pred.shape[1]
        # target = target.type_as(pred)  # [n]
        target = target.unsqueeze(-1).expand(B, C)  # [n,3]
        pt = (1 - pred_sigmoid) * target + pred_sigmoid * (1 - target)
        focal_weight = (self.alpha * target + (1 - self.alpha) *
                        (1 - target)) * pt.pow(self.gamma)
        loss = -F.binary_cross_entropy_with_logits(
            pred, target.float(), reduction='none') * focal_weight

        if reduction == 'mean':
            loss = loss.mean()
        if reduction == 'sum':
            loss = loss.sum()

        return loss


## 多分类的focal loss
class MultiCEFocalLoss(nn.Module):
    def __init__(self, class_num=3, gamma=2, alpha=None, reduction='mean'):
        super(MultiCEFocalLoss, self).__init__()
        if alpha is None: # 超参数
            self.alpha = Variable(torch.ones(class_num, 1)) #调节权重
        else:
            self.alpha = alpha
        self.gamma = gamma
        self.reduction = reduction
        self.class_num =  class_num

    def forward(self, predict, target):
        # pred: [n, 3]    target：[n]

        # 注意这里与二分类使用sigmoid不同的是，使用的是softmax
        pt = F.softmax(predict, dim=1) # softmax获取预测概率
        class_mask = F.one_hot(target, self.class_num) #获取target的one hot编码
        ids = target.view(-1, 1)  #[n,1]
        # alpha = self.alpha[ids.data.view(-1)].view(-1,1)
        alpha = self.alpha[ids.data.view(-1)]  # 注意，这里的alpha是给定的一个list(tensor),里面的元素分别是每一个类的权重因子
        probs = (pt * class_mask).sum(1).view(-1, 1)  #概率值：利用onehot作为mask，提取对应的pt
        log_p = probs.log()
        # 同样，原始ce上增加一个动态权重衰减因子
        alpha = alpha.cuda(0)
        loss = -alpha * (torch.pow((1 - probs), self.gamma)) * log_p

        if self.reduction == 'mean':
            loss = loss.mean()
        elif self.reduction == 'sum':
            loss = loss.sum()
        return loss


