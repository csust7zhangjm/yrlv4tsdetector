import os

from models.MLP_backbone import *
from models.head import DetectHead

from core.FiltersModule import *

from models.neck import *
from models.decoder import *

import thop
from thop import profile


class Detector(nn.Module):
    def __init__(self, category_num, out_channel=512):
        super(Detector, self).__init__()
        # 0) filters
        self.exposure = ExposureFilter()  # 曝光
        self.tone = ToneFilter()  # 色调（chromaticity）
        self.luminance = LumFilter()  # 亮度（intensity）

        # 滤波器网络
        self.cnnpp = FiltersModule()

        # 1) backbone
        # 1.3 MLP
        self.backbone = UNext()

        # 2) neck
        self.neck = MPN()

        # 3) head
        self.out_channel = out_channel
        self.decoder = DilatedEncoder(self.out_channel)
        self.detect_head = DetectHead(self.out_channel, category_num)

    def forward(self, x):
        # （1）数据增强
        out = self.cnnpp(x)  # [b, 10]

        # 滤波器变换
        x = self.exposure(x, torch.sigmoid(out[0]))  # x1

        x = self.tone(x, torch.sigmoid(out[1:9]) * 2)  # x2、x3、x4、x5、x6、x7、x8、x9

        x = self.luminance(x, torch.sigmoid(out[9]))  # x10

        # print(x.shape)  # [b, 3, 608, 608] 恢复原来的输入大小

        # print("-------------------------filter Module----------------------------")

        # （2）特征提取
        p5 = self.neck(self.backbone(x))


        # （3）检测
        return self.detect_head(self.decoder(p5))



def get_parameter_number(model):
    total_num = sum(p.numel() for p in model.parameters())
    trainable_num = sum(p.numel() for p in model.parameters() if p.requires_grad)
    return {'Total': total_num, 'Trainable': trainable_num}



if __name__ == "__main__":
    model = Detector(3)
    weights = torch.load(os.path.join('..', 'checkpoint', 'weight_AP05_0.929277_255-epoch.pth'), map_location='cpu')
    model.load_state_dict(weights['model'], strict=True)
    test_data = torch.rand(1, 3, 608, 608)
    model.eval()
    input_layer_names = ["images"]
    output_layer_names = ["output"]
    out = model(test_data)   #[b, 8, 19, 19]
    torch.onnx.export(model,
                      test_data,
                      f='model.onnx',
                      verbose=False,
                      opset_version=12,
                      training=torch.onnx.TrainingMode.EVAL,
                      do_constant_folding=True,
                      input_names=input_layer_names,
                      output_names=output_layer_names,
                      dynamic_axes=None)
#     print("out:", out.shape)
#     torch.save(model.state_dict(), "model.pth")   #81M
#
#     # 计算网络模型的计算量(FLOPs)和参数量(Params)
#     # FLOPS：浮点运算次数，指运行一次网络模型需要进行浮点运算的次数
#     # Params：网络模型中需要训练的参数总数
#     # 1. 计算网络参数量
#     print(get_parameter_number(model))  # 20.78M
#
#     # 2.计算FLOPS
#     flops, params = profile(model, inputs=(test_data, ))  #95.04G
#     print(flops / 1e9, params / 1e6)  # flops单位G，para单位M





