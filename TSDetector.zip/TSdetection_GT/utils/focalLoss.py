import torch.nn.functional as F
import torch.nn as nn


# 普通版focal loss
class FocalLoss(nn.Module):
    def __init__(self, gamma=2.0, alpha=0.25):
        super().__init__()
        self.bce = F.binary_cross_entropy_with_logits
        self.gamma = gamma
        self.alpha = alpha

    def forward(self, pred, target, reduction='mean'):
        # pred: [n, 3]    target：[n]
        pred_sigmoid = pred.sigmoid()  # [n,3]
        B, C = pred.shape[0], pred.shape[1]
        # target = target.type_as(pred)  # [n]
        target = target.unsqueeze(-1).expand(B, C)  # [n,3]
        pt = (1 - pred_sigmoid) * target + pred_sigmoid * (1 - target)
        focal_weight = (self.alpha * target + (1 - self.alpha) *
                        (1 - target)) * pt.pow(self.gamma)
        loss = -F.binary_cross_entropy_with_logits(
            pred, target.float(), reduction='none') * focal_weight

        if reduction == 'mean':
            loss = loss.mean()
        if reduction == 'sum':
            loss = loss.sum()

        return loss


